import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.util.*;

public class Login extends HttpServlet
{
	public void doGet(HttpServletRequest req, HttpServletResponse res)throws IOException, ServletException
	{
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		String nm =req.getParameter("user");
		String pwd = req.getParameter("pw");
		HttpSession ses = req.getSession();
		ses.setAttribute("name",nm);
		if(nm.equals("servlet") && pwd.equals("servlet"))
		{
			if(ses!=null)
					{
						RequestDispatcher  rd = req.getRequestDispatcher("/Welcome");
						rd.forward(req,res);
					}
					else
					{
						pw.print("Login first!!");
					}
		}
		else
		{
				RequestDispatcher  rd = req.getRequestDispatcher("/index.html");
				rd.forward(req,res);
				pw.print("incorrect");
		}


	}
}