import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.util.*;

public class Welcome extends HttpServlet
{
	public void doGet(HttpServletRequest req, HttpServletResponse res)throws IOException, ServletException
	{
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		HttpSession ses = req.getSession(false);
		String nm = (String)ses.getAttribute("name");
		RequestDispatcher  rd = req.getRequestDispatcher("/product.html");
		rd.forward(req,res);

	}
}