import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.util.*;

public class Product extends HttpServlet
{
	public void doGet(HttpServletRequest req, HttpServletResponse res)throws IOException, ServletException
	{
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		String pnm= req.getParameter("nm");
		String pp = req.getParameter("price");
		if()
	}
}